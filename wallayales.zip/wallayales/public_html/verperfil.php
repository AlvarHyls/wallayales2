<?php
$nombreusuario=$_GET["nombre"];
$conn = mysqli_connect("localhost","root","","wallayales");
$consulta ="SELECT * FROM usuarios where UserName='".$nombreusuario."'";
$resultado = mysqli_query($conn, $consulta);
while($row= mysqli_fetch_assoc($resultado)){

echo $row['UserName'];
echo"<br>";
echo"Email:  ";
echo $row['Email'];
echo"<br>";
echo"Edad:  ";
echo $row['Edad'];
echo"<br>";
echo"Telefono:  ";
echo $row['Telefono'];


}






 ?>
