var mensajes = new Array();
var UsuarioAct = sessionStorage.getItem("User");
var inicio = 0;
var cont = 0;

function cargarMensajes() {
    leer();
}

function visualizar() {
    if (cont !== 0) {
        document.getElementById("global").style.display = "block"
        document.getElementById("contador").innerHTML = "Nuevos mensajes:" + cont;
        for (i = 0; i < mensajes.length; i++) {
            if (i === inicio) {
                document.getElementById("remi").innerHTML = mensajes[i].Emisor;
                document.getElementById("mens").innerHTML = mensajes[i].Mensaje;
                document.getElementById("dest").innerHTML = mensajes[i].Receptor;
                document.getElementById("prod").innerHTML = mensajes[i].Producto; 
            }
        }

    } else {
        document.getElementById("contador").innerHTML = "No tienes nuevos Mensajes";
    }

}

function leer() {

    var xmlhttp = new XMLHttpRequest();
    var resp = ""
    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            resp = xmlhttp.responseText;
            var Registros = JSON.parse(resp);

            for (i = 0; i < Registros.length; i++) {
                mensajes[i] = Registros[i];
                if (mensajes[i].Receptor === UsuarioAct) {

                    cont += 1;


                }


            }

            visualizar();


        }
    }

    var cam = "http://localhost:3000/leerMensajes"
    xmlhttp.open("GET", cam, true);
    xmlhttp.send();

}

function siguiente() {
    if (inicio < mensajes.length - 1) {
        inicio = inicio + 1;
    }
    visualizar();
}

function anterior() {
    if (inicio !== 0) {
        inicio = inicio - 1;
    }
    visualizar();
}

function eliminarmensaje() {



    var jsonString = "Usuario=" + UsuarioAct +
        "&mensaje=" + document.getElementById("mens").innerHTML;




    var xmlhttp = new XMLHttpRequest();

    xmlhttp.open("POST", "http://localhost:3000/BorrarMensaje", true);
    xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");


    xmlhttp.send(jsonString);
    window.location.reload();




}

function contestar(){


  var receptor =document.getElementById("remi").innerHTML;
  var emisor = document.getElementById("dest").innerHTML;



  swal({
    title: 'Escriba su contestación:',
    input: 'text',
    showCancelButton: true,
    confirmButtonText: 'Enviar',
    preConfirm: function() {
      return new Promise(function(resolve) {
        swal.enableLoading();
        setTimeout(function() {
          resolve();
        }, 2000);
      });
    },
    allowOutsideClick: false
  }).then(function(email) {
    if (email) {
      swal({
        type: 'success',
        title: 'Respuesta enviada',

      });
      var jsonString = "Emisor=" + emisor +
          "&Receptor=" + receptor +
          "&Mensaje=" + email +
          "&Articulo=" + "Respuesta";



      var xmlhttp = new XMLHttpRequest();

      xmlhttp.open("POST", "http://localhost:3000/grabarMensajes", true);
      xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");


      xmlhttp.send(jsonString);


    }
  })






}
