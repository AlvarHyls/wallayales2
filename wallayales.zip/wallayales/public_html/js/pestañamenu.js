function mostrar_perfil() {

    document.getElementById("botones").style.display = "none";
    document.getElementById("perfil").style.display = "block";
    perfil();


}

function mostrar_perfil2() {

    document.getElementById("botones").style.display = "block";
    document.getElementById("perfil").style.display = "none";


}
