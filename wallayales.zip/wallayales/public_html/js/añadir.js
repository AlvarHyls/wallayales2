var nombre;

function GrabarProducto() {

    var Dueño = sessionStorage.getItem("User");
    var Nombre = document.getElementById("nombreProducto").value;
    var Descripcion = document.getElementById("descripcion").value;
    var Antiguedad = document.getElementById("antiguedad").value;
    var Categoria = document.getElementById("categoria").value;




    var jsonString = "Dueño=" + Dueño +
        "&Imagen=" + nombre +
        "&Nombre=" + Nombre +
        "&Descripcion=" + Descripcion +
        "&Antiguedad=" + Antiguedad +
        "&Categoria=" + Categoria;



    var xmlhttp = new XMLHttpRequest();

    xmlhttp.open("POST", "http://localhost:3000/grabarProductos", true);
    xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");


    xmlhttp.send(jsonString);
    document.getElementById("submit").submit();

}

function cargar_foto() {
    var Imagen = document.getElementById("imagen2").files;
    nombre = Imagen[0].name;
    document.getElementById("nombreProducto").value = nombre



}
