function grabarUsuario() {
    var usuario = document.getElementById("usernamesignup").value;
    var contraseña = document.getElementById("passwordsignup").value;
    var contraseña2 = document.getElementById("passwordsignup_confirm").value;
    var email = document.getElementById("emailsignup").value;
    var correo = document.getElementById("recepcion_correo");
    if (correo.checked == true) {
        var Correo = 1;
    } else {
        var Correo = 0;
    }

    if (contraseña !== contraseña2) {
        swal("Las contraseñas no coinciden ");
        var contraseña = document.getElementById("passwordsignup").style.background = "red";
        var contraseña2 = document.getElementById("passwordsignup_confirm").style.background = "red";
    } else {

        var jsonString = "Usuario=" + usuario +
            "&password=" + contraseña +
            "&email=" + email+
            "&correo"+Correo




        var xmlhttp = new XMLHttpRequest();

        xmlhttp.open("POST", "http://localhost:3000/grabarUsuario", true);
        xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");


        xmlhttp.send(jsonString);
        sessionStorage.setItem('User', usuario);
        location.href = "menu.html";
    }

}

function leerUsuario() {

    var username = document.getElementById("username").value;
    var password2 = document.getElementById("password").value;
    var be = false;



    var xmlhttp = new XMLHttpRequest();
    var resp = ""
    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            resp = xmlhttp.responseText;
            var Registros = JSON.parse(resp);

            for (i = 0; i < Registros.length; i++) {
                if (Registros[i].UserName === username && Registros[i].Password === password2) {
                    be = true;
                }
            }


            if (be === true) {
                sessionStorage.setItem('User', username);
                location.href = "menu.html";
            } else {
                swal("Su Usuario o Contraseña son erroneas");
                document.getElementById("username").value = "";
                document.getElementById("password").value = "";

            }
        }
    }

    var cam = "http://localhost:3000/leerUsuarios"
    xmlhttp.open("GET", cam, true);
    xmlhttp.send();








}
