/* conexion a la base de datos */
var express = require("express");
var mysql = require('mysql');
var url = require("url");
var http = require('http').Server(app);


var connection = mysql.createConnection({
    host: '127.0.0.1',
    user: 'root',
    password: '',
    database: 'wallayales'
});

var app = express();

app.use(function(req, res, next) {

    // Website you wish to allow to connect
    res.setHeader('Access-Control-Allow-Origin', 'http://localhost:3000');
    res.setHeader('Access-Control-Allow-Origin', '*');
    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    res.setHeader('Access-Control-Allow-Credentials', true);

    // Pass to next layer of middleware

    // res.header("Content-Type", "application/text; charset=utf-8");
    next();
});


connection.connect(function(err) {
    if (!err) {

        console.log("Database is connected ... \n\n");

    } else {
        console.log("Error connecting database ... \n\n");
    }
});

/* todas las interacciones del programa con la base de datos ,siendo su nombre la descripcion de la tarea que realizan */
app.post('/grabarUsuario', function(request, response) {


    var POST = {};
    if (request.method == 'POST') {
        request.on('data', function(data) {
            data = data.toString();
            data = data.split('&');
            //  console.log(data[0] + data[1]);
            for (var i = 0; i < data.length; i++) {
                var _data = data[i].split("=");
                POST[_data[0]] = _data[1];
            }
            //  var jSonString = JSON.stringify(POST);

            connection.query("INSERT INTO usuarios (ID, UserName, Email, Password, Correo)  VALUES (0,'" + POST.Usuario + "','" + POST.email + "','" + POST.password + "','" + POST.correo + "')", function(error) {
                if (error) {
                    console.log(error.message);
                } else {
                    console.log("succes");

                }
            });

        });

    }
});

app.get("/leerUsuarios", function(req, res) {
    connection.query('SELECT * from usuarios order by ID', function(err, rows, fields) {
        //connection.end();
        if (!err) {
            //  console.log('Registros ', rows);
            res.header("Access-Control-Allow-Origin", "*")
            json = JSON.stringify(rows);
            // console.log('Registros ', json);
            //res.sendFile(__dirname + '/index.html');//?mensaje=aaaa');}//+rows);
            /*  res.writeHead(200, { 'Content-Type': contentType, 'Access-Control-Allow-Origin': '*' });*/
            res.writeHead(200, {
                'Content-Type': 'text/plain',
                'Trailer': 'Content-MD5'
            });
            res.write(json);
            //res.addTrailers({'Content-MD5': "7895bf4b8828b55ceaf47747b4bca667"});
            res.end();
        } else {
            console.log('Error en la Select');
        }
    });
});

app.post('/actualizarUsuario', function(request, response) {


    var POST = {};
    if (request.method == 'POST') {
        request.on('data', function(data) {
            data = data.toString();
            data = data.split('&');
            //  console.log(data[0] + data[1]);
            for (var i = 0; i < data.length; i++) {
                var _data = data[i].split("=");
                POST[_data[0]] = _data[1];
            }
            //  var jSonString = JSON.stringify(POST);

            connection.query('UPDATE usuarios SET Email=? , Edad=? , Telefono=? WHERE UserName=?', [POST.temail, POST.edad, POST.telefono, POST.Usuario], function(error) {
                if (error) {
                    console.log(error.message);
                } else {
                    console.log("succes");

                }
            });

        });

    }
});

app.post('/grabarProductos', function(request, response) {


    var POST = {};
    if (request.method == 'POST') {
        request.on('data', function(data) {
            data = data.toString();
            data = data.split('&');
            //  console.log(data[0] + data[1]);
            for (var i = 0; i < data.length; i++) {
                var _data = data[i].split("=");
                POST[_data[0]] = _data[1];
            }
            //  var jSonString = JSON.stringify(POST);

            connection.query("INSERT INTO productos (ID, Dueño,Imagen, Nombre, Descripcion, Antiguedad, Categoria)  VALUES (0,'" + POST.Dueño + "','" + POST.Imagen + "','" + POST.Nombre + "','" + POST.Descripcion + "','" + POST.Antiguedad + "','" + POST.Categoria + "')", function(error) {
                if (error) {
                    console.log(error.message);
                } else {
                    console.log("succes");

                }
            });

        });

    }
});

app.get("/leerProductos", function(req, res) {
    connection.query('SELECT * from productos ', function(err, rows, fields) {
        //connection.end();
        if (!err) {
            //  console.log('Registros ', rows);
            res.header("Access-Control-Allow-Origin", "*")
            json = JSON.stringify(rows);
            // console.log('Registros ', json);
            //res.sendFile(__dirname + '/index.html');//?mensaje=aaaa');}//+rows);
            /*  res.writeHead(200, { 'Content-Type': contentType, 'Access-Control-Allow-Origin': '*' });*/
            res.writeHead(200, {
                'Content-Type': 'text/plain',
                'Trailer': 'Content-MD5'
            });
            res.write(json);
            //res.addTrailers({'Content-MD5': "7895bf4b8828b55ceaf47747b4bca667"});
            res.end();
        } else {
            console.log('Error en la Select');
        }
    });
});

app.get("/leerMensajes", function(req, res) {
    connection.query('SELECT * from mensajes ', function(err, rows, fields) {
        //connection.end();
        if (!err) {
            //  console.log('Registros ', rows);
            res.header("Access-Control-Allow-Origin", "*")
            json = JSON.stringify(rows);
            // console.log('Registros ', json);
            //res.sendFile(__dirname + '/index.html');//?mensaje=aaaa');}//+rows);
            /*  res.writeHead(200, { 'Content-Type': contentType, 'Access-Control-Allow-Origin': '*' });*/
            res.writeHead(200, {
                'Content-Type': 'text/plain',
                'Trailer': 'Content-MD5'
            });
            res.write(json);
            //res.addTrailers({'Content-MD5': "7895bf4b8828b55ceaf47747b4bca667"});
            res.end();
        } else {
            console.log('Error en la Select');
        }
    });
});

app.post('/grabarMensajes', function(request, response) {


    var POST = {};
    if (request.method == 'POST') {
        request.on('data', function(data) {
            data = data.toString();
            data = data.split('&');
            //  console.log(data[0] + data[1]);
            for (var i = 0; i < data.length; i++) {
                var _data = data[i].split("=");
                POST[_data[0]] = _data[1];
            }
            //  var jSonString = JSON.stringify(POST);

            connection.query("INSERT INTO mensajes (Emisor,Mensaje,Receptor,Producto)  VALUES ('" + POST.Emisor + "','" + POST.Mensaje + "','" + POST.Receptor + "','" + POST.Articulo + "')", function(error) {
                if (error) {
                    console.log(error.message);
                } else {
                    console.log("succes");

                }
            });

        });

    }
});

app.post('/BorrarProducto', function(request, response) {


    var POST = {};
    if (request.method == 'POST') {
        request.on('data', function(data) {
            data = data.toString();
            data = data.split('&');
            //  console.log(data[0] + data[1]);
            for (var i = 0; i < data.length; i++) {
                var _data = data[i].split("=");
                POST[_data[0]] = _data[1];
            }
            //  var jSonString = JSON.stringify(POST);

            connection.query('DELETE FROM `productos` WHERE   Dueño=? and  Nombre=? ', [POST.Usuario, POST.Nombre], function(error) {
                if (error) {
                    console.log(error.message);
                } else {
                    console.log("succes");

                }
            });

        });

    }
});

app.post('/BorrarMensaje', function(request, response) {


    var POST = {};
    if (request.method == 'POST') {
        request.on('data', function(data) {
            data = data.toString();
            data = data.split('&');
            //  console.log(data[0] + data[1]);
            for (var i = 0; i < data.length; i++) {
                var _data = data[i].split("=");
                POST[_data[0]] = _data[1];
            }
            //  var jSonString = JSON.stringify(POST);

            connection.query('DELETE FROM `mensajes` WHERE   Receptor=? and  Mensaje=? ', [POST.Usuario, POST.mensaje], function(error) {
                if (error) {
                    console.log(error.message);
                } else {
                    console.log("succes");

                }
            });

        });

    }
});

app.listen(3000);
