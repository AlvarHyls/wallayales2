var Productos = new Array();
var inicio = 0;
var UsuarioAct = sessionStorage.getItem("User");

function inicializar() {
      document.getElementById("cuerpo").style.display="none";
    leerProductos();

}

function visualizar() {

    if (Productos.length !== 0) {
        document.getElementById("cuerpo").style.display = "block";
        for (i = 0; i < Productos.length; i++) {

            if (i === inicio && Productos[i].Dueño === UsuarioAct) {

                var dueñoP = Productos[i].Dueño;
                var ImagenP = Productos[i].Imagen;
                var nombreP = Productos[i].Nombre;
                var antiguedadP = Productos[i].Antiguedad;



            }

        }
        document.getElementById("dueñop").innerHTML = dueñoP.toString();
        document.getElementById("nombrep").innerHTML = nombreP.toString();
        document.getElementById("antiguedadp").innerHTML = antiguedadP.toString();
        document.getElementById("imagen33").src = "ImagenesProductos/" + ImagenP;

    } else {

        document.getElementById("dueñop2").innerHTML = "No has añadido ningun objeto";
        document.getElementById("cuerpo").style.display="none";
    }

}

function leerProductos() {



    var cont = 0;


    var xmlhttp = new XMLHttpRequest();
    var resp = ""
    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            resp = xmlhttp.responseText;
            var Registros = JSON.parse(resp);

            for (i = 0; i < Registros.length; i++) {


                if (Registros[i].Dueño === UsuarioAct) {
                    Productos[cont] = Registros[i];
                    cont = cont + 1;
                }
            }
            visualizar();



        }
    }

    var cam = "http://localhost:3000/leerProductos"
    xmlhttp.open("GET", cam, true);
    xmlhttp.send();






}

function siguiente() {
    if (inicio < Productos.length - 1) {
        inicio = inicio + 1;
    }
    visualizar();
}

function anterior() {
    if (inicio !== 0) {
        inicio = inicio - 1;
    }
    visualizar();
}

function eliminarObjeto() {



    var jsonString = "Usuario=" + UsuarioAct +
        "&Nombre=" + document.getElementById("nombrep").innerHTML;




    var xmlhttp = new XMLHttpRequest();

    xmlhttp.open("POST", "http://localhost:3000/BorrarProducto", true);
    xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");


    xmlhttp.send(jsonString);

    location.href = "menu.html";



}
