function limpiar() {
    sessionStorage.setItem('User', "");
    document.getElementById("usernamesignup").value = "";
    document.getElementById("passwordsignup").value = "";
    document.getElementById("passwordsignup_confirm").value = "";
    document.getElementById("emailsignup").value = "";
    document.getElementById("username").value = "";
    document.getElementById("password").value = "";
}

function cerrar_sesion() {

    sessionStorage.setItem('User', "");
    location.href = "index.html";
}

function cambio() {

    document.getElementById("login").style.display = "none";
    document.getElementById("register").style.display = "block";



}

function cambio2() {

    document.getElementById("register").style.display = "none";
    document.getElementById("login").style.display = "block";



}

function comprobar() {
    UsuarioActual = sessionStorage.getItem("User");
    if (UsuarioActual === "") {

        cerrar_sesion();


    }



}
