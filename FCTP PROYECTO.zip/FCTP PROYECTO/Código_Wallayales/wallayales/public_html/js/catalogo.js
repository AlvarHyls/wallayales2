var Productos = new Array();
var emailP;
var inicio = 0;
var propios=0;
var UsuarioAct = sessionStorage.getItem("User");

function inicializar() {

    leerProductos();

}

function visualizar() {
    if (Productos.length !== 0) {
        document.getElementById("cuerpo").style.display = "block";
        for (i = 0; i < Productos.length; i++) {


            if (Productos[i].Dueño !== UsuarioAct && i == inicio) {

                var dueñoP = Productos[i].Dueño;
                var ImagenP = Productos[i].Imagen;
                var nombreP = Productos[i].Nombre;
                var descripcionP = Productos[i].Descripcion;
                var antiguedadP = Productos[i].Antiguedad;
                var categoriaP = Productos[i].Categoria;


            }

        }


        document.getElementById("dueñop").innerHTML = "Dueño: " + dueñoP.toString();
        document.getElementById("nombrep").innerHTML = "Nombre: " + nombreP.toString();
        document.getElementById("antiguedadp").innerHTML = "Antiguedad: " + antiguedadP.toString();
        document.getElementById("descripcionp").innerHTML = "Descripcion: " + descripcionP.toString();
        document.getElementById("pedidop").innerHTML = "Quiere: " + categoriaP.toString();
        document.getElementById("imagen33").src = "ImagenesProductos/" + ImagenP;
    }else{  document.getElementById("cuerpo").style.display="none";}

}

function leerProductos() {






    var xmlhttp = new XMLHttpRequest();
    var resp = ""
    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            resp = xmlhttp.responseText;
            var Registros = JSON.parse(resp);

            for (i = 0; i < Registros.length; i++) {
                Productos[i] = Registros[i];
                if(Registros[i].Dueño == UsuarioAct){
                  propios++;
                }

            }
            visualizar();



        }
    }

    var cam = "http://localhost:3000/leerProductos"
    xmlhttp.open("GET", cam, true);
    xmlhttp.send();






}

function siguiente() {


    if (inicio < Productos.length-1-propios) {
        inicio = inicio + 1;


    }
    visualizar();


}

function anterior() {
    if (inicio !== 0) {
        inicio = inicio - 1;
    }
    visualizar();

}

function enviar() {

    var recep = document.getElementById("dueñop").innerHTML;
    var receptor = recep.substring(7, recep.length)
    var emisor = UsuarioAct;
    var art = document.getElementById("nombrep").innerHTML;
    var articulo = art.substring(8, (art.length - 4))
    var mensaje = document.getElementById("escrito").value;
    document.getElementById("escrito").value = "";
    email()

    var jsonString = "Emisor=" + emisor +
        "&Receptor=" + receptor +
        "&Mensaje=" + mensaje +
        "&Articulo=" + articulo;



    var xmlhttp = new XMLHttpRequest();

    xmlhttp.open("POST", "http://localhost:3000/grabarMensajes", true);
    xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");


    xmlhttp.send(jsonString);









}
