    var UsuarioActual;

    function perfil() {
        UsuarioActual = sessionStorage.getItem("User");
        document.getElementById("Nombre").innerHTML = "Hola " + UsuarioActual + ", ";
        leerInfoUsuario(UsuarioActual);
    }



    function leerInfoUsuario(UsuarioActual) {

        var Nombre2 = UsuarioActual;
        var Seleccionado = new Array();





        var xmlhttp = new XMLHttpRequest();
        var resp = ""
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                resp = xmlhttp.responseText;
                var Registros = JSON.parse(resp);

                for (i = 0; i < Registros.length; i++) {

                    if (Registros[i].UserName === Nombre2) {

                        Seleccionado[0] = Registros[i].UserName;
                        Seleccionado[1] = Registros[i].Email;
                        Seleccionado[2] = Registros[i].Password;
                        Seleccionado[3] = Registros[i].Edad;
                        Seleccionado[4] = Registros[i].Telefono;

                    }
                }
                mostrarinfo(Seleccionado)



            }
        }

        var cam = "http://localhost:3000/leerUsuarios"
        xmlhttp.open("GET", cam, true);
        xmlhttp.send();





    }



    function mostrarinfo(lista) {

        document.getElementById("EmailP").value = lista[1];
        document.getElementById("Edad").value = lista[3];
        document.getElementById("Telefono").value = lista[4];
        

    }



    function updateUsuario() {

        var usuario = UsuarioActual;
        var Edad = document.getElementById("Edad").value;
        var Telefono = document.getElementById("Telefono").value;
        var email2 = document.getElementById("EmailP").value;


        var jsonString = "Usuario=" + usuario +
            "&edad=" + Edad +
            "&temail=" + email2 +
            "&telefono=" + Telefono





        var xmlhttp = new XMLHttpRequest();

        xmlhttp.open("POST", "http://localhost:3000/actualizarUsuario", true);
        xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");


        xmlhttp.send(jsonString);
        sessionStorage.setItem('User', usuario);
        location.href = "menu.html";

    }
